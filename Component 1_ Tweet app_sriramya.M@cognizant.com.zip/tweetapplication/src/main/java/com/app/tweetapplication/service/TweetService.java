package com.app.tweetapplication.service;

import java.util.List;

import com.app.tweetapplication.Entity.TweetEntity;
import com.app.tweetapplication.repository.TweetRepository;

public class TweetService {

	TweetRepository repo = new TweetRepository();
	public void saveTweet(String message, String username) throws Exception { 
		repo.savePost(message, username);
	}
	public List<TweetEntity> getUsertweets(String username) throws Exception{
		return repo.getPostsByUser(username);
	}
	public List<TweetEntity> getAlltweets(){
		return repo.getPosts();
	}	
}