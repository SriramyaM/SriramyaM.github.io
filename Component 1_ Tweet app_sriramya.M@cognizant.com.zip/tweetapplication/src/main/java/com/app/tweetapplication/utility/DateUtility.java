package com.app.tweetapplication.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.app.tweetapplication.constants.AppConstants;



public class DateUtility {
	public static Date convertToDate(String dob) {
		Date parsedDate = null;
		try {
			SimpleDateFormat date1 = new SimpleDateFormat(AppConstants.DOB);
			date1.setLenient(false);
			parsedDate = date1.parse(dob);
		} catch (ParseException parseException) {
			System.out.println("invalid Date format..."+AppConstants.DOB +" format");
		}
		return parsedDate;
	}
}