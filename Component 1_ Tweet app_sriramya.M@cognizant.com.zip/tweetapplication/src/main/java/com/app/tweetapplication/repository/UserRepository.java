package com.app.tweetapplication.repository;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.app.tweetapplication.Entity.UserEntity;
import com.app.tweetapplication.constants.AppConstants;
import com.app.tweetapplication.utility.DatabaseHandler;



public class UserRepository {

	private Connection connection;
	private PreparedStatement statement;
	private ResultSet rs;
	
	public UserEntity getUser(String username) throws Exception {
		connection = DatabaseHandler.getConnection();
		UserEntity user = new UserEntity();
		try {
			statement = connection.prepareStatement(AppConstants.GET_USER);
			statement.setString(1, username);
			rs = statement.executeQuery();
			if(rs.next()) {
					String email = rs.getString("us_email");
					String password = rs.getString("us_password");
					user.setEmail(email);
					user.setPassword(password);
			} else {
				throw new Exception();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection not disabled");
			}
		}
		return user;
	}

	public void saveUser(UserEntity user) throws Exception {
		
		connection = DatabaseHandler.getConnection();
		
		try {
			statement = connection.prepareStatement(AppConstants.SAVE_USER);
			statement.setString(1, user.getFirstname());
			statement.setString(2, user.getLastname());
			statement.setString(3, user.getGender());
			statement.setDate(4, new Date(user.getDob().getTime()));
			statement.setString(5, user.getEmail());
			statement.setString(6, user.getPassword());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection not disabled ");
			}
		}	
	}

	
	public void closedb() throws SQLException {

		if (rs != null) {
			rs.close();
		}
		
		if (statement != null) {
			statement.close();
		}
		
		if (connection != null) {
			connection.close();
		}
	}
}