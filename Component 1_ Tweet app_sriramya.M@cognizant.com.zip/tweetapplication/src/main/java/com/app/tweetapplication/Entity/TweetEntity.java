package com.app.tweetapplication.Entity;

public class TweetEntity {

	private String tweet;
	private UserEntity userDetails;
	

	public TweetEntity(String tweet, UserEntity userDetails) {
		super();
		this.tweet = tweet;
		this.userDetails = userDetails;
	}

	public String getTweet() {
		return tweet;
	}

	public void setTweet(String tweet) {
		this.tweet = tweet;
	}

	public UserEntity getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserEntity userDetails) {
		this.userDetails = userDetails;
	}

	@Override
	public String toString() {
		return "[tweet=" + tweet + ", userDetails=" + userDetails + "]";
	}
	public TweetEntity() {
		super();
	}

	
}