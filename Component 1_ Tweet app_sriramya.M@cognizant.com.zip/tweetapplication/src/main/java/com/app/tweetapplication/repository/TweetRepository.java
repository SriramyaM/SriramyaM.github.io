package com.app.tweetapplication.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.app.tweetapplication.Entity.TweetEntity;
import com.app.tweetapplication.constants.AppConstants;
import com.app.tweetapplication.utility.DatabaseHandler;



public class TweetRepository {

	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	public List<TweetEntity> getPosts() {
		conn = DatabaseHandler.getConnection();
		List<TweetEntity> posts = new ArrayList<>();
		try {
			ps = conn.prepareStatement(AppConstants.ALL_TWEETS);
			rs = ps.executeQuery();
			if(rs.next()) {
				do {
					String message = rs.getString("message");
					TweetEntity post = new TweetEntity();
					post.setTweet(message);
					posts.add(post);
				} while (rs.next());
			} else {
				System.err.println("No posts found");
			}
			return posts;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection is not closed properly");
			}
		}
		return posts;
	}

	public List<TweetEntity> getPostsByUser(String username) throws Exception {
		conn = DatabaseHandler.getConnection();
		List<TweetEntity> posts = new ArrayList<>();
		try {
			ps = conn.prepareStatement(AppConstants.USER_TWEETS);
			ps.setString(1, username);
			rs = ps.executeQuery();
			if(rs.next()) {
				do {
					String message = rs.getString("message");
					TweetEntity post = new TweetEntity();
					post.setTweet(message);
					posts.add(post);
				} while (rs.next());
			} else {
				throw new Exception();
			}
			return posts;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection is not closed properly");
			}
		}
		return posts;
	}

	public void savePost(String tweetMessage, String username) throws Exception {
		conn = DatabaseHandler.getConnection();
		try {
			ps = conn.prepareStatement(AppConstants.SAVE_TWEET);
			ps.setString(1, tweetMessage);
			ps.setString(2, username);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception();
		} finally {
			try {
				closedb();
			} catch (SQLException sqlException) {
				throw new RuntimeException("Connection is not closed properly");
			}
		}

	}
	public void closedb() throws SQLException {

		if (rs != null) {
			rs.close();
		}
		
		if (ps != null) {
			ps.close();
		}
		
		if (conn != null) {
			conn.close();
		}
		
	}
}
