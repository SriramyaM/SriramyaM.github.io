package com.app.tweetapplication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.app.tweetapplication.Entity.TweetEntity;
import com.app.tweetapplication.constants.AppConstants;
import com.app.tweetapplication.service.TweetService;
import com.app.tweetapplication.service.UserService;

	

public class TweetApplication 
{
	public static void main(String[] args) {

		UserService userService = new UserService();
		TweetService tweetService = new TweetService();
		boolean islogin = false;
		boolean isexit = true;
		String username = null;
		System.out.println("TWEET APP");
		while (isexit) {
			
			System.out.println("Select Any Choice :  ");
			System.out.println("1. Login");
			System.out.println("2. SignUp");
			System.out.println("3. Post a tweet");
			System.out.println("4. Show My Tweets");
			System.out.println("5. Show All Tweets");
			System.out.println("6. Logout");
			System.out.println("Press any other key to terminate...");
			BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
			String option;
			
			try {
				option = sc.readLine().trim();
				switch (option) {
				case "1": {
					
					if (islogin) {
						System.err.println("User already Logged in...");
					} else if (!islogin) {
						System.out.println("Enter email");
						String email = sc.readLine().trim();
						System.out.println("Enter password");
						String password = sc.readLine();
						try {
							if (userService.validateUser(email, password)) {
								username = email;
								islogin = true;
								System.out.println("login successfull");
							} else {
								System.err.println("invalid credentials");
							}
						} catch (Exception ex) {
							System.err.println("User not found...! Register Yourself....");
						}
					}
					break;
				}

				case "2": {
					if (!islogin) {
						System.out.println("User Registration...");
						System.out.println("Enter firstname");
						String firstname = sc.readLine().trim();
						System.out.println("Enter lastname");
						String lastname = sc.readLine().trim();
						System.out.println("Enter gender");
						String gender = sc.readLine().trim();
						System.out.println("Enter DateOfBirth " + AppConstants.DOB);
						String dob = sc.readLine().trim();
						System.out.println("Enter email");
						String email = sc.readLine().trim();
						System.out.println("Enter password");
						String password = sc.readLine();
						try {
							userService.saveUser(firstname, lastname, gender, dob, email, password);
							System.out.println("User Registerd Successfully");
						} catch (Exception ex) {
							System.err.println("email already exists.. Please login");
						}
					} else if (islogin) {
						System.err.println("user already logged in...");
					}
					break;
				}
				
				case "3": {
					if (!islogin) {
						System.err.println("Please login to post a tweet");
					} else if (islogin) {
						System.out.println("Enter tweet message...!");
						try {
							String Message = sc.readLine().trim();
							tweetService.saveTweet(Message, username);
							System.out.println("Message saved successfully.....!");
						} catch (Exception ex) {
							ex.printStackTrace();
						}
					}
					break;
				}

				case "4": {
					if (!islogin) {
						System.err.println("Please login to get your Tweets");
					} else if (islogin) {
						try {
							List<TweetEntity> userTweets = tweetService.getUsertweets(username);
							System.out.println("Your tweets: ");
							userTweets.forEach(tweet -> {
								System.out.println(tweet.getTweet());
							});
						} catch (Exception ex) {
							System.err.println("No tweets Posted " + username );
						}
					}
					break;
				}

				case "5": {
					List<TweetEntity> userTweets = tweetService.getAlltweets();
					System.out.println(" Your Tweets: ");
					userTweets.forEach(tweet -> {
						System.out.println(tweet.getTweet());
					});
					break;
				}

				case "6": {
					if (!islogin) {
						System.err.println("Please login first...");
					} else if (islogin) {
						username = null;
						islogin = false;
						System.out.println("Logged out successfully");
					}
					break;
				}
				
				default: {
					isexit = false;
					sc.close();
					break;
				}
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
}
