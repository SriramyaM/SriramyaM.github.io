package com.app.tweetapplication.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.app.tweetapplication.constants.AppConstants;




public class DatabaseHandler {

	public static Connection getConnection() {
		
		Connection conn = null;
		try {
			String driver = AppConstants.JDBC_DRIVER;
			String url = AppConstants.URL;
			String username = AppConstants.USER;
			String password = AppConstants.PASSWORD;
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException Exception) {
			
			throw new RuntimeException("Class Not Found Exception caught");
		} catch (SQLException Exception) {
			Exception.printStackTrace();
			throw new RuntimeException("SQL Exception caught");
		}
		return conn;
	}
}