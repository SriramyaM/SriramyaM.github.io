package com.app.tweetapplication.service;

import com.app.tweetapplication.Entity.UserEntity;
import com.app.tweetapplication.repository.UserRepository;
import com.app.tweetapplication.utility.DateUtility;

public class UserService {

	UserRepository repo = new UserRepository();
	public boolean validateUser(String email, String password) throws Exception {
		UserEntity existedUser = repo.getUser(email);
		if (existedUser != null) {
			if (existedUser.getPassword().equals(password)) {
				return true;
			} 
			else 
			{
				return false;
			}
		} 
		else {
			throw new Exception();
		}
	}
	public void saveUser(String fname, String lname, String gender, String dob, String email, String pwd) throws Exception {
		UserEntity newUser = new UserEntity(fname, lname, gender, DateUtility.convertToDate(dob), email, pwd);
		repo.saveUser(newUser);
	}
	
}